terraform state-persistence directory
=====================================

- used for storing the terraform state-variables when used inside container.
- This directory is empty when doing a fresh clone...
- Files created during terraform actions shall not be committed to git!